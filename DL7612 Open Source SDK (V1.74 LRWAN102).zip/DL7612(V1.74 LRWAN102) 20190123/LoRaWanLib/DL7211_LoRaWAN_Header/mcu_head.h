#ifndef __MCU_HEAD_H__
#define __MCU_HEAD_H__

/* USER CODE BEGIN Includes */
#include "am_mcu_apollo.h"
#include "am_bsp.h"
#include "am_util.h"
#include "define.h"


/* USER CODE END Includes */



/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */


/* Private variables ---------------------------------------------------------*/



/* Private function prototypes -----------------------------------------------*/




#endif
