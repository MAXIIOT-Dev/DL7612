/*
    _/_/_/    _/_/_/    _/_/_/  _/_/_/  _/      _/    _/_/_/  _/    _/  _/_/_/_/
   _/    _/    _/    _/          _/    _/_/    _/  _/        _/    _/  _/
  _/_/_/      _/      _/_/      _/    _/  _/  _/  _/  _/_/  _/_/_/_/  _/_/_/
 _/    _/    _/          _/    _/    _/    _/_/  _/    _/  _/    _/  _/
_/    _/  _/_/_/  _/_/_/    _/_/_/  _/      _/    _/_/_/  _/    _/  _/
    (C)2015 RisingHF, all rights reserved.

Description: loramac-node board dependent definitions

*/
#ifndef __BOARD_H__
#define __BOARD_H__

//���ݲ�ͬMCU���޸�
#include "mcu_head.h"

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#include "utilities.h"
#include "timer.h"
#include "radio.h"
#include "sx1276.h"
#include "rtc-board.h"
#include "timer-board.h"
#include "sx1276-board.h"
#include "app-lm.h"
#include "ISM_Band.h"

#include "AT_command.h"
#include "LoRaWan_api_v1.h"

#include "XS508.h"

/*!
 * NULL definition
 */
#ifndef NULL
    #define NULL                                    ( ( void * )0 )
#endif

/*!
 * Generic definition
 */
#ifndef SUCCESS
#define SUCCESS                                     1
#endif

#ifndef FAIL
#define FAIL                                        0
#endif

/*!
 * Unique Devices IDs register set ( STM32L1xxx )
 */
#define         ID1                                 ( 0x1FF80050 )
#define         ID2                                 ( 0x1FF80054 )
#define         ID3                                 ( 0x1FF80064 )
		
///*!
// * Unique Devices IDs register set ( STM32F1xxx )
// */		
//#define         ID1                                 ( 0x1ffff7e8 )
//#define         ID2                                 ( 0x1ffff7ec )
//#define         ID3                                 ( 0x1ffff7f0 )		

/*!
 * Random seed generated using the MCU Unique ID
 */
#define RAND_SEED                                   ( ( *( uint32_t* )ID1 ) ^ \
                                                      ( *( uint32_t* )ID2 ) ^ \
                                                      ( *( uint32_t* )ID3 ) )



/*!
 * \brief Measure the Battery level
 *
 * \retval value  battery level ( 0: very low, 254: fully charged )
 */
uint8_t BoardMeasureBatterieLevel( void );

/*!
 * \brief Gets the board 64 bits unique ID
 *
 * \param [IN] id Pointer to an array that will contain the Unique ID
 */


/* USER CODE BEGIN */

//-------------------__weak function begin------------------------//
extern void MOSI_HIGH(void);
extern void MOSI_LOW(void);
extern uint8_t MISO_Read(void);
extern void SCLK_HIGH(void);
extern void SCLK_LOW(void);
extern void NSS_HIGH(void);
extern void NSS_LOW(void);
extern void RXTX_HIGH(void);
extern void RXTX_LOW(void);
extern void RFRST_ON(void);
extern void RFRST_OFF(void);
extern uint8_t Read_DIO0(void);
extern uint8_t Read_DIO1(void);
extern uint8_t Read_DIO2(void);
extern uint8_t Read_DIO3(void);
extern uint8_t Read_DIO4(void);
extern uint8_t Read_DIO5(void);

//-------------------__weak function end------------------------//


void BoardGetUniqueId( uint8_t *id );
void DelayMs(uint16_t n);
uint16_t SpiInOut(uint16_t outData );

/* USER CODE END  */


#endif // __BOARD_H__
