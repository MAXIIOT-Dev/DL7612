
#include "define.h"

#define TX_H		am_hal_gpio_out_bit_set(44)
#define TX_L		am_hal_gpio_out_bit_clear(44)
#define RX		  am_hal_gpio_input_bit_read(37)

uint8_t gpioisrflag = 0;

void io_init (void)
{
    SPI_CS;
    SPI_CLK ;
    SPI_MOSI;
    SPI_MISO;
    RF_RXTX;
    RF_NRST;
    RF_FEM_CTX;
    RF_DIO0;
    RF_DIO1;
    RF_DIO2;
    RF_DIO3;
    RF_DIO4;
    RF_DIO5;
    RF_ON;
    XS508_SCL;
    XS508_SDA;
}


void intermit_io_init (void)
{
    am_hal_gpio_pin_config(36, AM_HAL_GPIO_INPUT); //RXD
    am_hal_gpio_int_polarity_bit_set(36, AM_HAL_GPIO_RISING);

    am_hal_gpio_int_clear(AM_HAL_GPIO_BIT(36));                     // Clear the GPIO Interrupt (write to clear).
    am_hal_gpio_int_enable(AM_HAL_GPIO_BIT(36));                    // Enable the GPIO interrupt.

    am_hal_interrupt_enable(AM_HAL_INTERRUPT_GPIO);                     // Enable GPIO interrupts to the NVIC.
    am_hal_interrupt_master_enable();

}


void
am_gpio_isr(void)
{
    //
    // Clear TimerA0 Interrupt (write to clear).
    //
    uint32_t ui32IOStatus;
    ui32IOStatus = am_hal_gpio_int_status_get(true);
    
    am_hal_gpio_int_clear(AM_HAL_GPIO_BIT(36));
    gpioisrflag = 1;
  
    am_hal_ctimer_int_clear(ui32IOStatus);
        
}
//*****************************************************************************
//
// UART configuration settings.
//
//*****************************************************************************
am_hal_uart_config_t g_sUartConfig =
{
    .ui32BaudRate = 115200,
    .ui32DataBits = AM_HAL_UART_DATA_BITS_8,
    .bTwoStopBits = false,
    .ui32Parity   = AM_HAL_UART_PARITY_NONE,
    .ui32FlowCtrl = AM_HAL_UART_FLOW_CTRL_NONE,
};

//*****************************************************************************
//
// Initialize the UART
//
//*****************************************************************************
void
uart_init(int32_t i32Module)
{
    //
    // Make sure the UART RX and TX pins are enabled.
    //
    am_bsp_pin_enable(COM_UART_TX);
    am_bsp_pin_enable(COM_UART_RX);

    //
    // Power on the selected UART
    //
    am_hal_uart_pwrctrl_enable(i32Module);

    //
    // Start the UART interface, apply the desired configuration settings, and
    // enable the FIFOs.
    //
    am_hal_uart_clock_enable(i32Module);

    //
    // Disable the UART before configuring it.
    //
    am_hal_uart_disable(i32Module);

    //
    // Configure the UART.
    //
    am_hal_uart_config(i32Module, &g_sUartConfig);

    //
    // Enable the UART FIFO.
    //
    //    am_hal_uart_fifo_config(i32Module,  AM_HAL_UART_RX_FIFO_1_2);
    am_hal_uart_int_clear(i32Module, 0xffffffff);


    am_hal_uart_int_clear(i32Module, AM_HAL_UART_INT_RX);
    am_hal_uart_int_enable(i32Module, AM_HAL_UART_INT_RX);
    am_hal_interrupt_enable(AM_HAL_INTERRUPT_UART);
    //
    // Enable the UART.
    //

    am_hal_uart_enable(i32Module);
}

//*****************************************************************************
//
// Enable the UART
//
//*****************************************************************************
void
uart_enable(int32_t i32Module)
{
    //
    // Enable the UART clock.
    //
    am_hal_uart_clock_enable(i32Module);

    //
    // Enable the UART.
    //
    am_hal_uart_enable(i32Module);

    //
    // Enable the UART pins.
    //
    am_bsp_pin_enable(COM_UART_TX);
    am_bsp_pin_enable(COM_UART_RX);
}

//*****************************************************************************
//
// Disable the UART
//
//*****************************************************************************
void
uart_disable(int32_t i32Module)
{
    //
    // Clear all interrupts before sleeping as having a pending UART interrupt
    // burns power.
    //
    am_hal_uart_int_clear(i32Module, 0xFFFFFFFF);

    //
    // Disable the UART.
    //
    am_hal_uart_disable(i32Module);

    //
    // Disable the UART pins.
    //
    am_bsp_pin_disable(COM_UART_TX);
    am_bsp_pin_disable(COM_UART_RX);

    //
    // Disable the UART clock.
    //
    am_hal_uart_clock_disable(i32Module);
}
//*****************************************************************************
//
// Transmit delay waits for busy bit to clear to allow
// for a transmission to fully complete before proceeding.
//
//*****************************************************************************
void
uart_transmit_delay(int32_t i32Module)
{
    //
    // Wait until busy bit clears to make sure UART fully transmitted last byte
    //
    while ( am_hal_uart_flags_get(i32Module) & AM_HAL_UART_FR_BUSY );
}


//*****************************************************************************
//
// Timer configurations.
//
//*****************************************************************************
am_hal_ctimer_config_t g_sTimer0 =
{
    // Don't link timers.
    0,

    // Set up TimerA0.
    (AM_HAL_CTIMER_FN_REPEAT |
    AM_HAL_CTIMER_INT_ENABLE |
    AM_HAL_CTIMER_LFRC_1HZ),

    // No configuration required for TimerB0.
    0,
};

//*****************************************************************************
//
// Init function for Timer A0.
//
//*****************************************************************************
void
timerA0_init(void)
{
    uint32_t ui32Period;

    //
    // Enable the LFRC.
    //
    am_hal_clkgen_osc_start(AM_HAL_CLKGEN_OSC_LFRC);

    //
    // Set up timer A0.
    //
    am_hal_ctimer_clear(0, AM_HAL_CTIMER_TIMERA);
    am_hal_ctimer_config(0, &g_sTimer0);

    //
    // Set the timing for timerA0.
    //
    ui32Period = 2 - 1;		//ui32Period��СֵΪ1����2-1
    am_hal_ctimer_period_set(0, AM_HAL_CTIMER_TIMERA, ui32Period,
                             (ui32Period >> 1));

    //
    // Clear the timer Interrupt
    //
    am_hal_ctimer_int_clear(AM_HAL_CTIMER_INT_TIMERA0);
}

//*****************************************************************************
//
// Timer configurations.
//
//*****************************************************************************
am_hal_ctimer_config_t g_sTimer3 =
{
    // link A and B together to make a long 24MHz counter
    0,

    // Set up timer 0AB to drive the ADC
    (AM_HAL_CTIMER_FN_PWM_REPEAT |
    AM_HAL_CTIMER_INT_ENABLE    |
    AM_HAL_CTIMER_XT_32_768KHZ),

    // Erase configuration, for linked mode only Timer2A controls things
    0,
};

//*****************************************************************************
//
// INIT TIMER A0 Function set for 5 second period.
//
//*****************************************************************************
void
timerA1_init(void)
{
    uint32_t ui32Period;
    //   am_hal_clkgen_osc_start(AM_HAL_CLKGEN_OSC_LFRC);
    //
    // Set up timer A1 to count 3MHz clocks but don't start it yet
    //
    am_hal_ctimer_clear(1, AM_HAL_CTIMER_TIMERA);
    am_hal_ctimer_config(1, &g_sTimer3);

    //
    // Set up timer A0 to generate 5 second triggers.
    // 12KHz from HFRC divided to 1 second period.
    //
    //
    ui32Period = 32; //1ms  TX

    am_hal_ctimer_period_set(1, AM_HAL_CTIMER_TIMERA, ui32Period,
                             (ui32Period >> 1));
    //   am_hal_ctimer_pin_enable(1, AM_HAL_CTIMER_TIMERA);

    //
    // Clear the timer Interrupt
    //
    am_hal_ctimer_int_clear(AM_HAL_CTIMER_INT_TIMERA1);
}
