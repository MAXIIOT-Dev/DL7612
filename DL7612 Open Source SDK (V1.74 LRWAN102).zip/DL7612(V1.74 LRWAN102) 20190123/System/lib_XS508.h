#ifndef __LIB_XS508_H__
#define __LIB_XS508_H__

/* USER CODE BEGIN Includes */
//#include "board.h"

/* USER CODE END Includes */



/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */


/* Private variables ---------------------------------------------------------*/



/* Private function prototypes -----------------------------------------------*/
//extern int XS508_Handshake(unsigned char *XS508_16B_Ukey,unsigned char *XS508_16B_ID);
extern int XS508_Handshake(unsigned char *Ukey,unsigned char *Udata);
extern void SCI_SLEEP(unsigned int n);

#endif
